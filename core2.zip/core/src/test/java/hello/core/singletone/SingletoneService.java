package hello.core.singletone;

public class SingletoneService {

    private static final SingletoneService instance = new SingletoneService();

    public static SingletoneService getInstance(){
        return instance;
    }
    private SingletoneService(){

    }

    public static void main(String[] args) {
        SingletoneService singletoneService = new SingletoneService();
    }
}
