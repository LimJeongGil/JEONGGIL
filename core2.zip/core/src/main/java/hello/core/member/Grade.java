package hello.core.member;

public enum Grade {
    Basic,
    VIP
}
